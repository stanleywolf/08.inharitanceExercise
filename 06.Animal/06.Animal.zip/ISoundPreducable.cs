﻿using System;
using System.Collections.Generic;
using System.Text;


interface ISoundPreducable
{
    string ProduceSound();
}